import com.google.common.io.ByteSink;
import com.google.common.io.FileWriteMode;
import com.google.common.io.Files;

import java.io.File;
import java.io.IOException;
import java.nio.charset.Charset;

/**
 * Created by muqing on 16/7/26.
 */
public class FileWrite {
    private String filePath;

    public FileWrite(String filePath) {
        this.filePath = filePath;
    }
    public void write(String context){
        File file = new File(filePath);
        try {
            Files.write(context,file, Charset.forName("utf-8"));
        } catch (IOException e) {
            e.printStackTrace();
        }

    }
}
