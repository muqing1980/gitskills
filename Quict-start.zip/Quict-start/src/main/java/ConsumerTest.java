import kafka.consumer.ConsumerIterator;
import kafka.consumer.KafkaStream;
import kafka.message.MessageAndMetadata;

/**
 * Created by muqing on 16/7/24.
 */
public class ConsumerTest implements Runnable {
    private KafkaStream stream;
    private int threadNum;

    public ConsumerTest(KafkaStream stream, int threadNum) {
        this.stream = stream;
        this.threadNum = threadNum;
    }

    @Override
    public void run() {
        ConsumerIterator<byte[], byte[]> it = stream.iterator();
        while (it.hasNext()) {
            MessageAndMetadata messageAndMetadata = it.next();
            System.out.println("Thread " + threadNum + ": " + new String((byte[])messageAndMetadata.message()));
        }
        System.out.println("Shutting down Thread: " + threadNum);
    }
}
