

import kafka.consumer.ConsumerConfig;
import kafka.consumer.KafkaStream;
import kafka.javaapi.consumer.ConsumerConnector;

import java.util.List;
import java.util.Map;
import java.util.HashMap;
import java.util.Properties;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;

/**
 * Created by muqing on 16/7/23.
 */
public class ConsumerGroupExample {
    private final ConsumerConnector consumer;
    private final String topic;
    private ExecutorService executorService;

    public ConsumerGroupExample(String groupId, String topic) {
        consumer = kafka.consumer.Consumer.createJavaConsumerConnector(createConsumerConfig(groupId));
        this.topic = topic;
    }

    private ConsumerConfig createConsumerConfig(String groupId) {
        Properties props = new Properties();
        props.put("zookeeper.connect", "localhost:2181");
        props.put("group.id", groupId);
        props.put("auto.offset.reset", "smallest");
        props.put("zookeeper.session.timeout.ms", "4000");
        props.put("zookeeper.sync.time.ms", "200");
        props.put("auto.commit.interval.ms", "1000");
        props.put("enable.auto.commit", "true");
        return new ConsumerConfig(props);
    }

    private void shutdown() {
        if (consumer != null) consumer.shutdown();
        if (executorService != null) executorService.shutdown();
        try {
            if (!executorService.awaitTermination(5000, TimeUnit.MILLISECONDS)) {
                System.out.println("Timed out waiting for consumer threads to shut down,exiting uncleanly");
            }
        } catch (InterruptedException e) {
            System.out.println(e.getMessage());
        }
    }

    public void run(int num) {
        Map<String, Integer> topicCountMap = new HashMap<String, Integer>();
        topicCountMap.put(topic, new Integer(1));
        Map<String, List<KafkaStream<byte[], byte[]>>> consumerMap = consumer.createMessageStreams(topicCountMap);
        executorService = Executors.newSingleThreadExecutor();
        KafkaStream stream = consumerMap.get(topic).get(0);
        executorService.execute(new ConsumerTest(stream, 1));
    }

    public static void main(String[] args) {
//        String groupId = args[0];
        String groupId = "mq1";
//        String topic = args[1];
        String topic = "mq";
        ConsumerGroupExample example = new ConsumerGroupExample(groupId, topic);
        example.run(1);
        try {
            Thread.sleep(100000);
        } catch (InterruptedException e) {

        }
        example.shutdown();
    }
}
