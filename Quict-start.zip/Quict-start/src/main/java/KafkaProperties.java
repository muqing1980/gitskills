/**
 * Created by muqing on 16/7/23.
 */
public class KafkaProperties {
    public static final String TOPIC = "mq";
    public static final int PORT = 9092;
    public static final int PRODUCER_BUFFER_SIZE=64*1024;
    public static final int CONNECTION_TIMEOUT=100000;
    public static final String CLIENT_ID = "mac_consumer_client";
    private KafkaProperties(){};
}
