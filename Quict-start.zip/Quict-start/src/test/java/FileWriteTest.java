import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.ExpectedException;
import org.junit.rules.TemporaryFolder;

import java.io.File;

import static org.assertj.core.api.Assertions.assertThat;


public class FileWriteTest {
    private FileWrite write;
    @Rule
    public TemporaryFolder temporaryFolder = new TemporaryFolder();
    @Rule
    public ExpectedException thrown = ExpectedException.none();

    @Test
    public void testWrite() throws Exception{
        File output = temporaryFolder.newFolder("report").toPath().resolve("output.data").toFile();
        write = new FileWrite(output.getPath());

        write.write("test");

        assertThat(output).hasContent("test").hasExtension("data").hasParent(resolvePath("report"));

    }

    private String resolvePath(String folder) {
        return temporaryFolder.getRoot().toPath().resolve(folder).toString();
    }
}